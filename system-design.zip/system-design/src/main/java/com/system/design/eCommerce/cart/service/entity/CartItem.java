package com.system.design.eCommerce.cart.service.entity;

public class CartItem {
    public String userId;
    public String productId;
    public int quantity;
    public double price;
}
