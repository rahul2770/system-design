package com.system.design.eCommerce.cart.service.service;

import com.system.design.eCommerce.cart.service.entity.CartItem;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class CartService {

    private RedisTemplate<String, CartItem> redis;

    public void add(String userId, CartItem item) {
        redis.opsForList()
            .rightPush("cart:" + userId, item);
    }
}
