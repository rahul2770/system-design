package com.system.design.eCommerce.order.service.entity;

import com.system.design.eCommerce.order.service.enums.OrderStatus;
import com.system.design.eCommerce.payment.service.enums.PaymentStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.List;

@Entity
public class Order {
    @Id
    private String orderId;
    private String userId;
    private double amount;
    private OrderStatus status;
    private List<String> productIds;
    private String paymentId;
    private PaymentStatus paymentStatus;
    private int totalPrice;
}
