package com.system.design.eCommerce.order.service.enums;

public enum OrderStatus {
    PLACED,
    UNDELIVERED,
    OUT_FOR_DELIVERY,
    DELIVERED,
}
