Functional Requirements
1. Initiate payment
2. Support multiple payment methods
3. Handle async confirmation (webhooks)
4. Update payment status
5. Trigger order state change
6. Handle failures & retries
7. Ensure idempotency

Non-Functional
1. High reliability
2. Exactly-once payment intent
3. PCI compliance (no card storage)
4. Eventual consistency

#Payement Flow
Order Service
 → Create Payment Intent
 → Redirect to Payment Gateway
 → Gateway Webhook (ASYNC)
 → Payment Service updates status
 → Kafka event to Order Service

 Order Created
  → Payment Initiated
  → Inventory Reserved
  → Payment SUCCESS
  → Order CONFIRMED
  → Notification sent

PaymentController
User clicks "Pay Now" → PaymentController → Creates Payment (INITIATED)
 → Calls Gateway (create intent) → Returns paymentId / redirect URL

WebhookController
Gateway completes payment → WebhookController → Verify signature
→ Update payment status → Publish PaymentEvent → Order Service consumes event


 Design Patterns Used
 | Pattern     | Usage                    |
 | ----------- | ------------------------ |
 | Strategy    | Multiple payment methods |
 | Factory     | Select payment strategy  |
 | Saga        | Order ↔ Payment workflow |
 | Command     | Payment initiation       |
 | Observer    | Kafka events             |
 | Idempotency | paymentId                |



