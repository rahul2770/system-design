package com.system.design.eCommerce.payment.service.controller;

import com.system.design.eCommerce.payment.service.pojo.PaymentRequest;
import com.system.design.eCommerce.payment.service.pojo.PaymentResponse;
import com.system.design.eCommerce.payment.service.service.PaymentService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping("/initiate")
    public PaymentResponse pay(@RequestBody PaymentRequest req) {

        return service.initiate(req);
    }
}
