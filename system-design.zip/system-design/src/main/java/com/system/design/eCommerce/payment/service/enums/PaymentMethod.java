package com.system.design.eCommerce.payment.service.enums;

public enum PaymentMethod {
    CASH,
    CREDIT_CARD,
    DEBIT_CARD,
    UPI,
    NET_BANKING
}
