package com.system.design.eCommerce.payment.service.enums;

public enum PaymentStatus {
    INITIATED,
    SUCCESS,
    FAILED
}
