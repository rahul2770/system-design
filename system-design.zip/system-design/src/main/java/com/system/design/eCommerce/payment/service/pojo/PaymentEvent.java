package com.system.design.eCommerce.payment.service.pojo;

import com.system.design.eCommerce.payment.service.entity.Payment;
import com.system.design.eCommerce.payment.service.enums.PaymentStatus;

public class PaymentEvent {

    public String orderId;
    public String paymentId;
    public PaymentStatus status;

    public PaymentEvent(Payment p) {
        this.orderId = p.getOrderId();
        this.paymentId = p.getPaymentId();
        this.status = p.getStatus();
    }
}
