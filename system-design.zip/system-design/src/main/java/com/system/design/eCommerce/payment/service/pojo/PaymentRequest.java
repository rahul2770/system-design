package com.system.design.eCommerce.payment.service.pojo;

import com.system.design.eCommerce.payment.service.enums.PaymentMethod;

public class PaymentRequest {

    public String orderId;
    private String userId;
    public double amount;
    public PaymentMethod method;
}
