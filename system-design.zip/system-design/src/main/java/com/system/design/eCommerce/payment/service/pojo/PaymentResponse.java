package com.system.design.eCommerce.payment.service.pojo;

public class PaymentResponse {

    public String paymentId;
    public String status;
}
