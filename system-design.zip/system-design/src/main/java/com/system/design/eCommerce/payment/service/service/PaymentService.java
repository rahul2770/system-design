package com.system.design.eCommerce.payment.service.service;

import com.system.design.eCommerce.payment.service.entity.Payment;
import com.system.design.eCommerce.payment.service.enums.PaymentStatus;
import com.system.design.eCommerce.payment.service.pojo.PaymentRequest;
import com.system.design.eCommerce.payment.service.pojo.PaymentResponse;
import com.system.design.eCommerce.payment.service.repositories.PaymentRepository;
import com.system.design.eCommerce.payment.service.strategy.PaymentStrategyFactory;
import java.time.Instant;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository repo;
    private final PaymentStrategyFactory factory;
    private final KafkaTemplate<String, PaymentEvent> kafka;

    public PaymentService(PaymentRepository repo,
                          PaymentStrategyFactory factory,
                          KafkaTemplate<String, PaymentEvent> kafka) {
        this.repo = repo;
        this.factory = factory;
        this.kafka = kafka;
    }

    public PaymentResponse initiate(PaymentRequest req) {

        // Idempotency check
        repo.findByOrderId(req.orderId)
            .ifPresent(p -> {
                throw new IllegalStateException("Payment already exists");
            });

        Payment payment = new Payment();
        payment.setPaymentId(UUID.randomUUID().toString());
        payment.setOrderId(req.orderId);
        payment.setAmount(req.amount);
        payment.setMethod(req.method);
        payment.setStatus(PaymentStatus.INITIATED);
        payment.setCreatedAt(Instant.now());

        repo.save(payment);

        factory.get(req.method).initiate(payment);

        PaymentResponse res = new PaymentResponse();
        res.paymentId = payment.getPaymentId();
        res.status = payment.getStatus().name();
        return res;
    }
}
