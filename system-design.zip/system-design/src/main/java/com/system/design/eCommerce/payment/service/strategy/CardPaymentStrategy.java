package com.system.design.eCommerce.payment.service.strategy;

import com.system.design.eCommerce.payment.service.entity.Payment;
import org.springframework.stereotype.Component;

@Component
public class CardPaymentStrategy implements PaymentStrategy {

    @Override
    public void initiate(Payment payment) {
        // Call external card gateway
        System.out.println("Initiating card payment");
    }
}
