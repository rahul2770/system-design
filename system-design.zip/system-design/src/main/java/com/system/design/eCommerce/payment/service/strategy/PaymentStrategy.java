package com.system.design.eCommerce.payment.service.strategy;

import com.system.design.eCommerce.payment.service.entity.Payment;

public interface PaymentStrategy {
    void initiate(Payment payment);
}
