package com.system.design.eCommerce.payment.service.strategy;

import com.system.design.eCommerce.payment.service.enums.PaymentMethod;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class PaymentStrategyFactory {

    private final Map<PaymentMethod, PaymentStrategy> strategies;

    public PaymentStrategyFactory(
        List<PaymentStrategy> list) {

        strategies = new HashMap<>();
        list.forEach(s -> {
            if (s instanceof CardPaymentStrategy) {
                strategies.put(PaymentMethod.DEBIT_CARD, s);
            }
            if (s instanceof UpiPaymentStrategy) {
                strategies.put(PaymentMethod.UPI, s);
            }
        });
    }

    public PaymentStrategy get(PaymentMethod method) {
        return strategies.get(method);
    }
}
