package com.system.design.eCommerce.payment.service.strategy;

import com.system.design.eCommerce.payment.service.entity.Payment;
import org.springframework.stereotype.Component;

@Component
public class UpiPaymentStrategy implements PaymentStrategy {

    @Override
    public void initiate(Payment payment) {
        System.out.println("Initiating UPI payment");
    }
}
