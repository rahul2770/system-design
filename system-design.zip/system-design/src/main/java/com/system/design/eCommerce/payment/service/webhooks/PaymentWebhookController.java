package com.system.design.eCommerce.payment.service.webhooks;

import com.system.design.eCommerce.payment.service.entity.Payment;
import com.system.design.eCommerce.payment.service.enums.PaymentStatus;
import com.system.design.eCommerce.payment.service.pojo.PaymentEvent;
import com.system.design.eCommerce.payment.service.repositories.PaymentRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments/webhook")
public class PaymentWebhookController {

    private PaymentRepository repo;
    private KafkaTemplate<String, PaymentEvent> kafka;
    private WebhookSignatureVerifier verifier;

    @PostMapping
    public ResponseEntity<String> handle(@RequestBody WebhookPayload payload) {

        if (!verifier.verify(payload)) {
            return ResponseEntity.status(401).body("Invalid signature");
        }

        Payment payment = repo.findById(payload.paymentId)
                .orElseThrow();

        // Idempotency check
        if (payment.getStatus() == PaymentStatus.SUCCESS) {
            return ResponseEntity.ok("Already processed");
        }

        payment.setStatus(
            "SUCCESS".equals(payload.status)
                ? PaymentStatus.SUCCESS
                : PaymentStatus.FAILED
        );

        repo.save(payment);

        kafka.send("payment-topic",
                new PaymentEvent(payment));

        return ResponseEntity.ok("Webhook processed");
    }
}
