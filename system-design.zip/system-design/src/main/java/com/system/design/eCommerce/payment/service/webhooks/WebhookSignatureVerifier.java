package com.system.design.eCommerce.payment.service.webhooks;

import org.springframework.stereotype.Component;

@Component
public class WebhookSignatureVerifier {

    private static final String SECRET = "gateway-secret";

    public boolean verify(WebhookPayload payload) {

        String data = payload.paymentId +
                      payload.gatewayTxnId +
                      payload.status +
                      payload.amount;

        String expected = hmacSha256(data, SECRET);

        return expected.equals(payload.signature);
    }

    private String hmacSha256(String data, String key) {
        // Implement HMAC SHA-256
        return "";
    }
}
