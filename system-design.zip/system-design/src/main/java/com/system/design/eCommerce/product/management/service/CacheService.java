package com.system.design.eCommerce.product.management.service;

import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue.Supplier;
import java.util.concurrent.TimeUnit;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class CacheService {

    private RedisTemplate<String, Object> redis;

    public <T> T get(String key, Supplier<T> dbCall) {

        Object cached = redis.opsForValue().get(key);
        if (cached != null) {
            return (T) cached;
        }

        T value = dbCall.get();
        redis.opsForValue().set(key, value, 10, TimeUnit.MINUTES);
        return value;
    }
}
