package com.system.design.eCommerce.product.management.service;

import com.system.design.eCommerce.product.management.entity.Product;
import com.system.design.eCommerce.product.management.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    @Autowired
    private CacheService cache;

    public Product getProduct(String id) {

        return cache.get("product:" + id,
            () -> repo.findById(id)
                .orElseThrow());
    }
}
