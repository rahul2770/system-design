package com.system.design.eCommerce.user.management.entity;

import com.system.design.eCommerce.user.management.enums.Role;
import com.system.design.eCommerce.user.management.pojo.Credential;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    private String userId;
    private String email;
    private String firstName;
    private String lastName;
    private Credential credential;
    private List<String> orderHistory;
    private List<String> favoriteProducts;
    private String profilePictureUrl;
    private Role role;

}
