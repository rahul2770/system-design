package com.system.design.eCommerce.user.management.enums;

public enum ProductCategory {
    FASHION,
    FOOD,
    BEAUTY,
    ELECTRONICS,
    GROCERY
}
