package com.system.design.eCommerce.user.management.enums;

public enum Role {
    USER,
    SELLER,
    ADMIN,
}
