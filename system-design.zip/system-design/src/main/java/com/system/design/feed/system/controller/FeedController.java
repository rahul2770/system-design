package com.system.design.feed.system.controller;


import com.system.design.feed.system.pojo.FeedResponse;
import com.system.design.feed.system.services.FeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/feed")
public class FeedController {

    @Autowired
    private FeedService feedService;

    @GetMapping
    public FeedResponse feed(@RequestHeader("userId") String userId,
            @RequestParam(required = false) String cursor) {
        return feedService.getFeed(userId, cursor);
    }
}
