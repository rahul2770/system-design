package com.system.design.feed.system.controller;


import com.system.design.feed.system.pojo.CreatePostRequest;
import com.system.design.feed.system.services.PostService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @PostMapping
    public void create(@RequestBody CreatePostRequest req,
                       @RequestHeader("userId") String userId) {
        postService.create(req, userId);
    }
}
