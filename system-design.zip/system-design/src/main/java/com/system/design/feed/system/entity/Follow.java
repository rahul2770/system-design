package com.system.design.feed.system.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "follows")
public class Follow {

    @Id
    private String id;

    private String followerId;
    private String followeeId;
}
