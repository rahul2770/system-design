package com.system.design.feed.system.pojo;


import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class ChronologicalRanking implements FeedRankingStrategy {

    public List<FeedItem> rank(List<FeedItem> items) {
        return items.stream()
                .sorted(Comparator.comparing(
                        FeedItem::getCreatedAt).reversed())
                .toList();
    }
}
