package com.system.design.feed.system.pojo;


import com.system.design.feed.system.entity.Follow;
import com.system.design.feed.system.repositories.FollowRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class FeedFanoutConsumer {
    @Autowired
    private FollowRepository followRepo;

    @Autowired
    private RedisTemplate<String, FeedItem> redis;

    @KafkaListener(topics = "post-topic")
    public void consume(PostEvent event) {

        List<Follow> followers = followRepo.findByFolloweeId(event.userId);
        for (Follow f : followers) {
            redis.opsForList().leftPush(
                    "feed:" + f.getFollowerId(),
                    new FeedItem(event.postId,
                            event.userId,
                            event.createdAt)
            );
        }
    }
}
