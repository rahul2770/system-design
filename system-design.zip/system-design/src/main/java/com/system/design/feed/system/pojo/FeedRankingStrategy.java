package com.system.design.feed.system.pojo;

import java.util.List;

public interface FeedRankingStrategy {
    List<FeedItem> rank(List<FeedItem> items);
}
