package com.system.design.feed.system.pojo;

import java.util.List;

public class FeedResponse {
    public List<FeedItem> getItems() {
        return items;
    }

    public void setItems(List<FeedItem> items) {
        this.items = items;
    }

    public String getNextCursor() {
        return nextCursor;
    }

    public void setNextCursor(String nextCursor) {
        this.nextCursor = nextCursor;
    }

    public List<FeedItem> items;
    public String nextCursor;
}
