package com.system.design.feed.system.pojo;

@Component
public class FeedStrategyFactory {

    private final Map<String, FeedRankingStrategy> strategies;

    public FeedStrategyFactory(
        List<FeedRankingStrategy> list) {

        strategies = list.stream()
            .collect(Collectors.toMap(
                s -> s.getClass().getSimpleName(), s -> s));
    }

    public FeedRankingStrategy get(String type) {
        return strategies.get(type);
    }
}
