package com.system.design.feed.system.pojo;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class MLBasedRanking implements FeedRankingStrategy {

    public List<FeedItem> rank(List<FeedItem> items) {
        // Placeholder for ML score
        return items;
    }
}
