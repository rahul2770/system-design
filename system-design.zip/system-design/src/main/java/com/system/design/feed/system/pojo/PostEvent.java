package com.system.design.feed.system.pojo;

import com.system.design.feed.system.entity.Post;
import java.io.Serializable;
import java.time.Instant;

/**
 * Domain Event representing creation of a Post.
 * Used for async fan-out to feeds, notifications, analytics.
 */
public class PostEvent implements Serializable {

    private String postId;
    private String userId;
    private String mediaUrl;
    private String caption;
    private Instant createdAt;

    // Required for Kafka deserialization
    public PostEvent() {}

    public PostEvent(Post post) {
        this.postId = post.getPostId();
        this.userId = post.getUserId();
        this.mediaUrl = post.getMediaUrl();
        this.caption = post.getCaption();
        this.createdAt = post.getCreatedAt();
    }

    // getters only → IMMUTABLE EVENT
    public String getPostId() { return postId; }
    public String getUserId() { return userId; }
    public String getMediaUrl() { return mediaUrl; }
    public String getCaption() { return caption; }
    public Instant getCreatedAt() { return createdAt; }
}
