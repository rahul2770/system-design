Core Responsibilities
1. create posts (text / media)
2. Generate user feed
3. Rank & order feed items
4. Handle follow relationships
5. Support fan-out (push / pull)
6. Cache feeds
7. Paginate efficiently
8. Scale to millions of users

Tech Stack
| Layer      | Technology             |
| ---------- | ---------------------- |
| API        | Spring Boot            |
| Auth       | JWT / OAuth            |
| DB         | Cassandra / PostgreSQL |
| Cache      | Redis                  |
| Messaging  | Kafka                  |
| Media      | S3 + CDN               |
| Search     | Elasticsearch          |
| Deployment | AWS ECS / EKS          |

High-Level Architecture
Client
 │
 ▼
API Gateway
 │
 ▼
Feed Service (Spring Boot)
 │
 ├── Post Service
 ├── Follow Service
 ├── Feed Generation Service
 │
 ├── Redis (Feed Cache)
 ├── Kafka (Fan-out)
 └── DB (Posts, Follows)

Fan-out Strategy
| User Type    | Strategy         |
| ------------ | ---------------- |
| Normal users | Fan-out on write |
| Celebrities  | Fan-out on read  |


Solid Principles
1. Single Responsibility
   a. PostService → post creation
   b. FeedService → feed generation
   c. RankingService → ordering logic
2. Open/Closed Principle: Feed ranking is pluggable via strategy pattern.
3. Liskov Substitution: All feed strategies follow a common interface.
4. Interface Segregation: Separate interfaces for ranking, caching, publishing.
5. Dependency Inversion: Services depend on interfaces, not implementations.


Design patterns used:
| Pattern   | Usage                   |
| --------- | ----------------------- |
| Strategy  | Feed ranking            |
| Factory   | Feed strategy selection |
| Observer  | Kafka event listeners   |
| Decorator | Feed enrichment         |
| Command   | Post creation events    |
| Singleton | Redis connection        |
