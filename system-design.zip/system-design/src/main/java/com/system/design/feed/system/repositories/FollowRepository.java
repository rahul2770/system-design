package com.system.design.feed.system.repositories;

import com.system.design.feed.system.entity.Follow;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FollowRepository
        extends JpaRepository<Follow, String> {

    List<Follow> findByFollowerId(String followerId);
    List<Follow> findByFolloweeId(String followeeId);
}
