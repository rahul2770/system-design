package com.system.design.feed.system.repositories;

import com.system.design.feed.system.entity.Like;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LikeRepository extends JpaRepository<Like, String> {

    List<Like> findByLikeId(String likeId);
}
