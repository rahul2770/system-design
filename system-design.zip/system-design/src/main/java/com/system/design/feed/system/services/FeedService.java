package com.system.design.feed.system.services;

import com.system.design.feed.system.pojo.ChronologicalRanking;
import com.system.design.feed.system.pojo.FeedItem;
import com.system.design.feed.system.pojo.FeedRankingStrategy;
import com.system.design.feed.system.pojo.FeedResponse;
import java.util.List;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class FeedService {

    private final RedisTemplate<String, List<FeedItem>> redis;
    private final FeedRankingStrategy ranking;

    public FeedService(RedisTemplate redis, ChronologicalRanking ranking) {
        this.redis = redis;
        this.ranking = ranking;
    }

    public FeedResponse getFeed(String userId, String cursor) {

        String key = "feed:" + userId;

        List<FeedItem> items = redis.opsForList().range(key, 0, 100);

        List<FeedItem> ranked = ranking.rank(items);

        FeedResponse r = new FeedResponse();
        r.items = ranked;
        r.nextCursor = "next";
        return r;
    }
}
