package com.system.design.feed.system.services;


import com.system.design.feed.system.entity.Post;
import com.system.design.feed.system.pojo.CreatePostRequest;
import com.system.design.feed.system.pojo.PostEvent;
import com.system.design.feed.system.repositories.PostRepository;
import java.time.Instant;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class PostService {

    @Autowired
    private PostRepository repo;
    private final KafkaTemplate<String, PostEvent> kafka;

    public PostService(PostRepository repo,
                       KafkaTemplate<String, PostEvent> kafka) {
        this.repo = repo;
        this.kafka = kafka;
    }

    public void create(CreatePostRequest req, String userId) {

        Post post = new Post();
        post.setPostId(UUID.randomUUID().toString());
        post.setUserId(userId);
        post.setCaption(req.caption);
        post.setMediaUrl(req.mediaUrl);
        post.setCreatedAt(Instant.now());
        repo.save(post);

        kafka.send("post-topic", userId, new PostEvent(post));
    }
}
