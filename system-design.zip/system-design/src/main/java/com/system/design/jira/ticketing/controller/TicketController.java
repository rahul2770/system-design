package com.system.design.jira.ticketing.controller;

import com.system.design.jira.ticketing.pojo.CreateTicketRequest;
import com.system.design.jira.ticketing.pojo.TicketResponse;
import com.system.design.jira.ticketing.pojo.UpdateTicketRequest;
import com.system.design.jira.ticketing.services.CommentService;
import com.system.design.jira.ticketing.services.TicketService;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService service;
    private final CommentService commentService;

    public TicketController(TicketService service,
                            CommentService commentService) {
        this.service = service;
        this.commentService = commentService;
    }

    @PostMapping
    public TicketResponse create(
            @RequestBody CreateTicketRequest req,
            @RequestHeader("userId") String userId) {

        return service.create(req, userId);
    }

    @PutMapping("/{id}")
    public TicketResponse update(
            @PathVariable String id,
            @RequestBody UpdateTicketRequest req) {

        return service.update(id, req);
    }

    @PostMapping("/{id}/comments")
    public void comment(
            @PathVariable String id,
            @RequestBody String content,
            @RequestHeader("userId") String userId) {

        commentService.addComment(id, userId, content);
    }
}
