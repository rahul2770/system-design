package com.system.design.jira.ticketing.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
