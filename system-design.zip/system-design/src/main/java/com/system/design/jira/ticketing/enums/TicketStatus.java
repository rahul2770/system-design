package com.system.design.jira.ticketing.enums;

public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    DONE,
    CLOSED
}
