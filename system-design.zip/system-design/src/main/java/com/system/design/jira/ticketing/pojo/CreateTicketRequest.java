package com.system.design.jira.ticketing.pojo;

import com.system.design.jira.ticketing.enums.Priority;

public class CreateTicketRequest {

    public String title;
    public String description;
    public Priority priority;
}
