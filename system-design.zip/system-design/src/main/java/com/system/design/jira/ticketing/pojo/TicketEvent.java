package com.system.design.jira.ticketing.pojo;

public class TicketEvent {
    public String ticketId;
    public String action; // CREATED, UPDATED
}
