package com.system.design.jira.ticketing.pojo;

import com.system.design.jira.ticketing.enums.Priority;
import com.system.design.jira.ticketing.enums.TicketStatus;

public class TicketResponse {

    public String id;
    public String title;
    public TicketStatus status;
    public Priority priority;
    public String assigneeId;
}
