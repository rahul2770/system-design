package com.system.design.jira.ticketing.pojo;

import com.system.design.jira.ticketing.enums.Priority;
import com.system.design.jira.ticketing.enums.TicketStatus;

public class UpdateTicketRequest {
    private String ticketId;
    public TicketStatus status;
    public String assigneeId;
    public Priority priority;
}
