package com.system.design.jira.ticketing.repositories;

import com.system.design.jira.ticketing.entity.Ticket;
import com.system.design.jira.ticketing.enums.TicketStatus;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TicketRepository
        extends JpaRepository<Ticket, String> {

    List<Ticket> findByAssigneeId(String assigneeId);

    List<Ticket> findByStatus(TicketStatus status);
}
