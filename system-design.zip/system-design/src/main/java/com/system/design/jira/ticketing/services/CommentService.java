package com.system.design.jira.ticketing.services;

import com.system.design.jira.ticketing.entity.Comment;
import com.system.design.jira.ticketing.entity.Ticket;
import com.system.design.jira.ticketing.repositories.CommentRepository;
import com.system.design.jira.ticketing.repositories.TicketRepository;
import java.time.Instant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    private final CommentRepository repo;
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private TicketRepository ticketRepo;


    public CommentService(CommentRepository repo) {
        this.repo = repo;
    }

    public void addComment(String ticketId, String userId, String content) {

        Comment c = new Comment();
        c.setTicketId(ticketId);
        c.setAuthorId(userId);
        c.setContent(content);
        c.setCreatedAt(Instant.now());
        repo.save(c);
        notifyAll(ticketRepo.findById(ticketId));
    }
    private void notifyAll(Ticket ticket) {
        String mssg = "Ticket Updated:" + ticket.toString();
        notificationService.sendNotification(ticket.getAssigneeId(), mssg);
        notificationService.sendNotification(ticket.getReporterId(), mssg);// Notify all stakeholders about the ticket update
    }

}
