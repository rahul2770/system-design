package com.system.design.jira.ticketing.services;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    public void sendNotification(String userId, String message) {
        // Logic to send notification (e.g., email, SMS, in-app)
        System.out.println("Notification sent to user " + userId + ": " + message);
    }
}
