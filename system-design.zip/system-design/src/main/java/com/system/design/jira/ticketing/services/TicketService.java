package com.system.design.jira.ticketing.services;

import com.system.design.jira.ticketing.entity.Ticket;
import com.system.design.jira.ticketing.enums.TicketStatus;
import com.system.design.jira.ticketing.pojo.CreateTicketRequest;
import com.system.design.jira.ticketing.pojo.TicketResponse;
import com.system.design.jira.ticketing.pojo.UpdateTicketRequest;
import com.system.design.jira.ticketing.repositories.TicketRepository;
import java.time.Instant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

    private final TicketRepository ticketRepo;

    @Autowired
    private NotificationService notificationService;

    public TicketService(TicketRepository ticketRepo) {
        this.ticketRepo = ticketRepo;
    }

    public TicketResponse create(CreateTicketRequest req, String reporterId) {

        Ticket ticket = new Ticket();
        ticket.setTitle(req.title);
        ticket.setDescription(req.description);
        ticket.setPriority(req.priority);
        ticket.setStatus(TicketStatus.OPEN);
        ticket.setReporterId(reporterId);
        ticket.setCreatedAt(Instant.now());
        ticket.setUpdatedAt(Instant.now());

        Ticket saved = ticketRepo.save(ticket);
        return toResponse(saved);
    }

    public TicketResponse update(String ticketId, UpdateTicketRequest req) {

        Ticket ticket = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));

        if (req.status != null) {
            validateTransition(ticket.getStatus(), req.status);
            ticket.setStatus(req.status);
        }

        if (req.assigneeId != null) {
            ticket.setAssigneeId(req.assigneeId);
        }

        if (req.priority != null) {
            ticket.setPriority(req.priority);
        }

        ticket.setUpdatedAt(Instant.now());
        ticketRepo.save(ticket);
        notifyAll(ticket);
        return toResponse(ticket);
    }

    private void validateTransition(
            TicketStatus from, TicketStatus to) {

        if (from == TicketStatus.DONE && to == TicketStatus.IN_PROGRESS) {
            throw new IllegalStateException("Invalid transition");
        }
    }

    private TicketResponse toResponse(Ticket t) {
        TicketResponse r = new TicketResponse();
        r.id = t.getId();
        r.title = t.getTitle();
        r.status = t.getStatus();
        r.priority = t.getPriority();
        r.assigneeId = t.getAssigneeId();
        return r;
    }

    private void notifyAll(Ticket ticket) {
        String mssg = "Ticket Updated:" + ticket.toString();
        notificationService.sendNotification(ticket.getAssigneeId(), mssg);
        notificationService.sendNotification(ticket.getReporterId(), mssg);// Notify all stakeholders about the ticket update
    }
}
