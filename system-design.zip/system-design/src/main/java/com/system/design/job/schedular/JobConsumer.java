package com.system.design.job.schedular;

import com.system.design.job.schedular.entity.JobEntity;
import com.system.design.job.schedular.entity.JobExecutionEntity;
import com.system.design.job.schedular.repository.JobExecutionRepository;
import com.system.design.job.schedular.repository.JobRepository;
import java.util.UUID;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class JobConsumer {

    private final JobRepository jobRepo;
    private final JobExecutionRepository executionRepo;
    private final RetryService retryService;

    public JobConsumer(JobRepository jobRepo, JobExecutionRepository executionRepo, RetryService retryService) {
        this.jobRepo = jobRepo;
        this.executionRepo = executionRepo;
        this.retryService = retryService;
    }

    @KafkaListener(topics = "job-topic", groupId = "job-executors")
    public void consume(String jobId) {

        if (executionRepo.existsByJobIdAndStatus(jobId, "SUCCESS")) {
            return; // Idempotency
        }

        JobEntity job = jobRepo.findById(jobId).orElseThrow();

        try {
            execute(job);

            executionRepo.save(new JobExecutionEntity(UUID.randomUUID().toString(), jobId, 1, "SUCCESS"));

        } catch (Exception e) {
            retryService.retry(jobId);
        }
    }

    private void execute(JobEntity job) {
        System.out.println("Executing job: " + job.getPayload());
    }
}
