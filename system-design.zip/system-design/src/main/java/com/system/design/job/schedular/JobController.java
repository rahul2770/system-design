package com.system.design.job.schedular;

import com.system.design.job.schedular.pojo.JobRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jobs")
public class JobController {

    @Autowired
    private JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @PostMapping
    public String createJob(@RequestBody JobRequest request) {
        return jobService.createJob(request);
    }

    @PostMapping("/{id}/pause")
    public void pause(@PathVariable String id) {
        jobService.pauseJob(id);
    }
}
