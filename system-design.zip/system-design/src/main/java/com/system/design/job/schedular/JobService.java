package com.system.design.job.schedular;

import com.system.design.job.schedular.entity.JobEntity;
import com.system.design.job.schedular.entity.TriggerEntity;
import com.system.design.job.schedular.pojo.JobRequest;
import com.system.design.job.schedular.repository.JobRepository;
import com.system.design.job.schedular.repository.TriggerRepository;
import java.time.Instant;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class JobService {

    private final JobRepository jobRepo;
    private final TriggerRepository triggerRepo;

    public JobService(JobRepository jobRepo,
                      TriggerRepository triggerRepo) {
        this.jobRepo = jobRepo;
        this.triggerRepo = triggerRepo;
    }

    public String createJob(JobRequest req) {

        String jobId = UUID.randomUUID().toString();

        JobEntity job = new JobEntity();
        job.setJobId(jobId);
        job.setJobType(req.getType());
        job.setCronExpression(req.getCron());
        job.setPayload(req.getPayload());
        job.setMaxRetries(3);
        job.setStatus("ACTIVE");

        jobRepo.save(job);

        TriggerEntity trigger = new TriggerEntity();
        trigger.setTriggerId(UUID.randomUUID().toString());
        trigger.setJobId(jobId);
        trigger.setNextRunTime(Instant.now().plusSeconds(10));
        trigger.setStatus("WAITING");

        triggerRepo.save(trigger);

        return jobId;
    }

    public void pauseJob(String jobId) {
        jobRepo.findById(jobId)
               .ifPresent(j -> {
                   j.setStatus("PAUSED");
                   jobRepo.save(j);
               });
    }
}
