package com.system.design.job.schedular;

@Service
public class RetryService {

    private final KafkaTemplate<String, String> kafkaTemplate;

    public void retry(String jobId) {
        kafkaTemplate.send("retry-topic", jobId);
    }

    @KafkaListener(topics = "retry-topic")
    public void retryConsumer(String jobId) {
        kafkaTemplate.send("job-topic", jobId);
    }

    @KafkaListener(topics = "dlq-topic")
    public void dlq(String jobId) {
        System.err.println("Job moved to DLQ: " + jobId);
    }
}
