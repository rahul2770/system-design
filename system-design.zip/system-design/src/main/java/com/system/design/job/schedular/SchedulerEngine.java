package com.system.design.job.schedular;

import com.system.design.job.schedular.entity.TriggerEntity;
import com.system.design.job.schedular.repository.TriggerRepository;
import java.time.Instant;
import java.util.List;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class SchedulerEngine {

    private final TriggerRepository triggerRepo;
    private final KafkaTemplate<String, String> kafkaTemplate;

    public SchedulerEngine(TriggerRepository triggerRepo,
                           KafkaTemplate<String, String> kafkaTemplate) {
        this.triggerRepo = triggerRepo;
        this.kafkaTemplate = kafkaTemplate;
    }

    @Scheduled(fixedDelay = 5000)
    public void schedule() {

        List<TriggerEntity> triggers =
                triggerRepo.findDueTriggers(Instant.now());

        for (TriggerEntity trigger : triggers) {

            kafkaTemplate.send("job-topic", trigger.getJobId());

            trigger.setStatus("RUNNING");
            triggerRepo.save(trigger);
        }
    }
}
