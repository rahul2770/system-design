package com.system.design.job.schedular.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//JobExecutionEntity (Idempotency)
@Entity
@Table(name = "job_executions")
public class JobExecutionEntity {
    @Id
    private Long id;
    @Id
    private String executionId;

    private String jobId;
    private int attempt;
    private String status;

    public JobExecutionEntity(String string, String jobId, int i, String success) {
        this.executionId = string;
        this.jobId = jobId;
        this.attempt = i;
        this.status = success;
    }

    public JobExecutionEntity() {
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public int getAttempt() {
        return attempt;
    }

    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    // SUCCESS, FAILED
}
