package com.system.design.job.schedular.enums;

enum JobType { ONE_TIME, CRON }
public enum JobStatus { ACTIVE, PAUSED, COMPLETED }
enum ExecutionStatus { SUCCESS, FAILED, TIMEOUT }
enum TriggerStatus { WAITING, RUNNING }