package com.system.design.job.schedular.pojo;

import java.util.Objects;

public class JobRequest {

    private String type;
    private String cron;
    private String payload;

    public JobRequest() {
    }

    public JobRequest(String type, String cron, String payload) {
        this.type = type;
        this.cron = cron;
        this.payload = payload;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "JobRequest{" +
                "type='" + type + '\'' +
                ", cron='" + cron + '\'' +
                ", payload='" + payload + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JobRequest that = (JobRequest) o;
        return Objects.equals(type, that.type) &&
                Objects.equals(cron, that.cron) &&
                Objects.equals(payload, that.payload);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, cron, payload);
    }
}
