package com.system.design.job.schedular.repository;

import com.system.design.job.schedular.entity.JobExecutionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobExecutionRepository
        extends JpaRepository<JobExecutionEntity, String> {
    boolean existsByJobIdAndStatus(String jobId, String status);
}
