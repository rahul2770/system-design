package com.system.design.job.schedular.repository;

import com.system.design.job.schedular.entity.JobEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository
        extends JpaRepository<JobEntity, String> {
}
