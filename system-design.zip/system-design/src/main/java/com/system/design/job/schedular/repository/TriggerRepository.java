package com.system.design.job.schedular.repository;

import com.system.design.job.schedular.entity.TriggerEntity;
import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TriggerRepository
        extends JpaRepository<TriggerEntity, String> {

    @Query("""
        SELECT t FROM TriggerEntity t
        WHERE t.nextRunTime <= :now
        AND t.status = 'WAITING'
    """)
    List<TriggerEntity> findDueTriggers(Instant now);
}
