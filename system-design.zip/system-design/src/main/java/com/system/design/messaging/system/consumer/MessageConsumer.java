package com.system.design.messaging.system.consumer;

import com.system.design.messaging.system.pojo.MessageEvent;
import com.system.design.messaging.system.services.RedisService;
import com.system.design.messaging.system.services.WebSocketService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {

    private final RedisService redis;
    private final WebSocketService socketService;

    public MessageConsumer(RedisService redis,
                           WebSocketService socketService) {
        this.redis = redis;
        this.socketService = socketService;
    }

    @KafkaListener(
        topics = "message-topic",
        groupId = "message-consumer"
    )
    public void consume(MessageEvent event) {

        if (redis.isDuplicate(event.getMessageId())) {
            return;
        }

        if (redis.isUserOnline(event.getReceiverId())) {
            socketService.push(event.getReceiverId(), event);
        } else {
            // Offline → push notification / store
        }
    }

    @KafkaListener(topics = "read-topic")
    public void readReceipt(String messageId) {
        repo.findById(messageId).ifPresent(m -> {
            m.setStatus("READ");
            repo.save(m);
        });
    }

}
