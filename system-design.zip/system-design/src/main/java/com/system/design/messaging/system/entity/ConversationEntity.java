package com.system.design.messaging.system.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.springframework.data.annotation.Id;

@Entity
@Table(name = "conversations")
public class ConversationEntity {

    @jakarta.persistence.Id
    private Long id;
    @Id
    private String conversationId;

    private boolean isGroup;
    private String participants; // CSV / JSON
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
