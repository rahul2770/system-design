package com.system.design.messaging.system.pojo;

import java.util.List;

class Conversation {
    String conversationId;
    List<String> participants;
    boolean isGroup;
}
