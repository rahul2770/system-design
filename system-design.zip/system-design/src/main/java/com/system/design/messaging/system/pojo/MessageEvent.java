package com.system.design.messaging.system.pojo;

import com.system.design.messaging.system.entity.Message;

public class MessageEvent {

    private String messageId;
    private String conversationId;
    private String senderId;
    private String receiverId;
    private String payload;

    public MessageEvent(Message m) {
        this.messageId = m.getMessageId();
        this.conversationId = m.getConversationId();
        this.senderId = m.getSenderId();
        this.receiverId = m.getReceiverId();
        this.payload = m.getEncryptedPayload();
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }
}
