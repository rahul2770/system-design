package com.system.design.messaging.system.pojo;

public class MessageResponse {
    private String messageId;
    private String status;
}
