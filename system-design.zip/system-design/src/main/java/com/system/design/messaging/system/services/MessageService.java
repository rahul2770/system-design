package com.system.design.messaging.system.services;

import com.system.design.messaging.system.entity.Message;
import com.system.design.messaging.system.pojo.MessageEvent;
import com.system.design.messaging.system.pojo.MessageRequest;
import com.system.design.messaging.system.pojo.MessageResponse;
import com.system.design.messaging.system.repositories.MessageRepository;
import java.util.UUID;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageService {

    private final KafkaTemplate<String, MessageEvent> kafkaTemplate;
    private final MessageRepository messageRepo;

    public MessageResponse sendMessage(MessageRequest req) {

        String messageId = UUID.randomUUID().toString();

        Message msg = new Message();
        msg.setMessageId(messageId);
        msg.setConversationId(req.getConversationId());
        msg.setSenderId(req.getSenderId());
        msg.setReceiverId(req.getReceiverId());
        msg.setContent(req.getContent());
        msg.setStatus("SENT");
        msg.setTimestamp(Instant.now());

        // Persist for durability
        messageRepo.save(msg);

        // Publish to Kafka
        kafkaTemplate.send(
            "message-topic",
            msg.getConversationId(),
            new MessageEvent(msg)
        );

        return new MessageResponse(messageId, "SENT");
    }
}
