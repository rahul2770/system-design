package com.system.design.messaging.system.services;

@Service
public class RedisService {

    private final StringRedisTemplate redis;

    public RedisService(StringRedisTemplate redis) {
        this.redis = redis;
    }

    public boolean isUserOnline(String userId) {
        return redis.hasKey("online:" + userId);
    }

    public boolean isDuplicate(String messageId) {
        String key = "dedup:" + messageId;
        if (redis.hasKey(key)) {
            return true;
        }
        redis.opsForValue().set(key, "1", 1, TimeUnit.HOURS);
        return false;
    }

    public void markOnline(String userId) {
        redis.opsForValue().set("online:" + userId, "1", 30, TimeUnit.SECONDS);
    }
}
