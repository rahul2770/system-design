package com.system.design.messaging.system.services;

import com.system.design.messaging.system.pojo.MessageEvent;
import org.springframework.stereotype.Component;

@Component
public class WebSocketService {

    public void push(String userId, MessageEvent event) {
        // Lookup socket session from Redis
        // Send message to client
    }
}
