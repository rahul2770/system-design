package com.system.design.messaging.system.websocket;

import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

@Component
public class MessageSocketHandler extends TextWebSocketHandler {

    private static final Map<String, WebSocketSession> sessions
        = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        String userId = session.getPrincipal().getName();
        sessions.put(userId, session);
    }

    public void send(String userId, MessageEvent event) {
        WebSocketSession session = sessions.get(userId);
        if (session != null && session.isOpen()) {
            session.sendMessage(
                new TextMessage(event.getPayload())
            );
        }
    }
}
