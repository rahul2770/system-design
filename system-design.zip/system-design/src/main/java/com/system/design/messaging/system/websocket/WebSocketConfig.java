package com.system.design.messaging.system.websocket;

import org.springframework.context.annotation.Configuration;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final MessageSocketHandler handler;

    public WebSocketConfig(MessageSocketHandler handler) {
        this.handler = handler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry reg) {
        reg.addHandler(handler, "/ws")
           .setAllowedOrigins("*");
    }
}
