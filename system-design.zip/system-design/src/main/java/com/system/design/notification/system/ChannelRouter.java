package com.system.design.notification.system;

import com.system.design.notification.system.channel.NotificationChannel;
import com.system.design.notification.system.enums.NotificationType;
import com.system.design.notification.system.models.Notification;
import java.util.Map;

//Strategy Pattern
public class ChannelRouter {

    Map<NotificationType, NotificationChannel> channels;

    public void route(Notification notification, String content) {
        channels.get(notification.type).send(notification, content);
    }
}