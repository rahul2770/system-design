package com.system.design.notification.system.Exceptions;

public class NotificationNotAllowedException {
    public String message;
    public NotificationNotAllowedException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }
}
