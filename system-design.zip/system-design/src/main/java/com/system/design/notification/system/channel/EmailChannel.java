package com.system.design.notification.system.channel;

import com.system.design.notification.system.models.Notification;

class EmailChannel implements NotificationChannel {

    EmailProvider emailProvider;

    public void send(Notification notification, String content) {
        emailProvider.sendEmail(notification.userId, content);
    }
}