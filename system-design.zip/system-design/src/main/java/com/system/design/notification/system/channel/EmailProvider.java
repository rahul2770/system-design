package com.system.design.notification.system.channel;

public class EmailProvider {
    public void sendEmail(String userId, String content) {
        System.out.println("Sending email to " + userId + " with content " + content);
    }
}
