package com.system.design.notification.system.channel;

import com.system.design.notification.system.models.Notification;

public interface NotificationChannel {
    void send(Notification notification, String content);
}
