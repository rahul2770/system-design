package com.system.design.notification.system.consumer;

import com.system.design.notification.system.ChannelRouter;
import com.system.design.notification.system.models.Notification;
import com.system.design.services.RetryService;

//Async Processing (Consumer)

public class NotificationConsumer {

    ChannelRouter channelRouter;
    RetryService retryService;

    void consume(Notification notification) {
        try {
            channelRouter.route(notification, notification.getContent());
        } catch (Exception e) {
            retryService.retry(notification);
        }
    }
}