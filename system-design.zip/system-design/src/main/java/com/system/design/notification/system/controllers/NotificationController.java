package com.system.design.notification.system.controllers;

import com.system.design.notification.system.models.NotificationRequest;
import com.system.design.notification.system.models.NotificationResponse;
import com.system.design.services.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/notify")
    public NotificationResponse send(@RequestBody NotificationRequest request) {
        return notificationService.sendNotification(request);
    }
}