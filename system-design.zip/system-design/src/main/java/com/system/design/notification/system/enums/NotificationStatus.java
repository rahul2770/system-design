package com.system.design.notification.system.enums;

public enum NotificationStatus {
    PENDING, SENT, FAILED, RETRYING
}
