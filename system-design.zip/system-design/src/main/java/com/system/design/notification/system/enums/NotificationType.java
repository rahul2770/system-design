package com.system.design.notification.system.enums;

public enum NotificationType {
    EMAIL,
    SMS,
    PUSH,
    IN_APP
}
