package com.system.design.notification.system.models;

import com.system.design.notification.system.enums.NotificationStatus;
import com.system.design.notification.system.enums.NotificationType;
import java.time.LocalDateTime;
import java.util.Map;

public class Notification {
    String notificationId;
    public String userId;
    public NotificationType type;     // EMAIL, SMS, PUSH, IN_APP
    String templateId;
    Map<String, String> payload;
    public NotificationStatus status;
    public int retryCount;
    LocalDateTime createdAt;

    public Notification(String notificationId, String userId, NotificationType type, String templateId, Map<String, String> payload) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.type = type;
        this.templateId = templateId;
        this.payload = payload;
    }

    public String getContent() {
        return payload.get("content");
    }
}
