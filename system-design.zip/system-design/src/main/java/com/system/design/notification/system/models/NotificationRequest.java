package com.system.design.notification.system.models;

import com.system.design.notification.system.enums.NotificationType;
import java.util.Map;

public class NotificationRequest {
    public String userId;
    public NotificationType type;
    public String templateId;
    public Map<String, String> payload;
    boolean async;
}