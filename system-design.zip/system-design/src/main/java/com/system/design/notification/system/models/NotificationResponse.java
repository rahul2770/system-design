package com.system.design.notification.system.models;

import com.system.design.notification.system.enums.NotificationStatus;

public class NotificationResponse {
    String notificationId;
    NotificationStatus status;
}
