package com.system.design.notification.system.producer;

import com.system.design.notification.system.models.Notification;

public class QueueProducer {
    public void publish(Notification message) {
        System.out.println("Publishing message " + message);
    }
}
