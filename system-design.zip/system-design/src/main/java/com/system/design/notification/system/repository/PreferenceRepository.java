package com.system.design.notification.system.repository;

import org.springframework.stereotype.Repository;

@Repository
public class PreferenceRepository {
}
