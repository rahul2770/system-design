package com.system.design.notification.system.services;

import com.system.design.notification.system.models.NotificationRequest;
import com.system.design.notification.system.models.NotificationResponse;
import org.springframework.stereotype.Service;

@Service
public interface NotificationService {
    NotificationResponse sendNotification(NotificationRequest notificationRequest);
}
