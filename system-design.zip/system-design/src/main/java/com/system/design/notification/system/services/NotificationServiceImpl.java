package com.system.design.notification.system.services;

import com.system.design.notification.system.ChannelRouter;
import com.system.design.notification.system.Exceptions.NotificationNotAllowedException;
import com.system.design.notification.system.models.Notification;
import com.system.design.notification.system.models.NotificationRequest;
import com.system.design.notification.system.models.NotificationResponse;
import com.system.design.notification.system.producer.QueueProducer;
import com.system.design.services.TemplateService;

import static com.system.design.notification.system.enums.NotificationStatus.PENDING;
import static com.system.design.notification.system.enums.NotificationStatus.SENT;

public class NotificationServiceImpl implements NotificationService{
    PreferenceService preferenceService;
    TemplateService templateService;
    ChannelRouter channelRouter;
    QueueProducer queueProducer;

    @Override
    public NotificationResponse sendNotification(NotificationRequest request) {

        if (!preferenceService.isAllowed(request.userId, request.type)) {
            throw new NotificationNotAllowedException("Notification not allowed for user");
        }

        String content = templateService.render(
                request.templateId, request.payload);

        Notification notification = NotificationMapper.toEntity(request);

        if (request.async) {
            queueProducer.publish(notification);
            return new NotificationResponse(notification.notificationId, PENDING);
        }

        channelRouter.route(notification, content);
        return new NotificationResponse(notification.notificationId, SENT);
    }

    }
}
