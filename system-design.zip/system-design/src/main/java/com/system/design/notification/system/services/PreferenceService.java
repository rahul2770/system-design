package com.system.design.notification.system.services;

import com.system.design.notification.system.enums.NotificationType;
import com.system.design.notification.system.repository.PreferenceRepository;

public class PreferenceService {
    PreferenceRepository repository;

    boolean isAllowed(String userId, NotificationType type) {
        return repository.isEnabled(userId, type);
    }
}
