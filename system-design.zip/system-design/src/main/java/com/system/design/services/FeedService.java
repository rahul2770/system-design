package com.system.design.services;

public interface FeedService {
}
