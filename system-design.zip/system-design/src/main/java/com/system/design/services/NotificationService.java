package com.system.design.services;

import com.system.design.notification.system.models.NotificationRequest;
import com.system.design.notification.system.models.NotificationResponse;

public interface NotificationService {
    NotificationResponse sendNotification(NotificationRequest request);
}
