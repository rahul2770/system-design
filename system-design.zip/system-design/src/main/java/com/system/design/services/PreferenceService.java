package com.system.design.services;

import com.system.design.notification.system.enums.NotificationType;

class PreferenceService {

    PreferenceRepository repository;

    boolean isAllowed(String userId, NotificationType type) {
        return repository.isEnabled(userId, type);
    }
}