package com.system.design.services;

import com.system.design.notification.system.models.Notification;

import static com.system.design.notification.system.enums.NotificationStatus.FAILED;

public class RetryService {

    static final int MAX_RETRIES = 3;

    public void retry(Notification notification) {
        if (notification.retryCount < MAX_RETRIES) {
            notification.retryCount++;
            // Re-enqueue
        } else {
            notification.status = FAILED;
        }
    }
}