package com.system.design.services;

public class TemplateService {

    TemplateRepository repository;

    public String render(String templateId, Map<String, String> data) {
        String template = repository.getTemplate(templateId);
        return TemplateEngine.render(template, data);
    }
}